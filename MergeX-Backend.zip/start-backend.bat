@echo off
title MergeX Backend Printer Service
color 0a
cd /d "%~dp0"

echo ========================================================
echo       MERGEX - LOCAL BACKEND ^& BARTENDER PRINTER PROXY
echo ========================================================
echo Working Directory: %CD%
echo.

:: Check Node.js
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    color 0c
    echo [ERROR] Node.js is not installed on this computer!
    echo Please download and install Node.js from: https://nodejs.org
    echo.
    pause
    exit /b 1
)

:: Auto install node_modules if missing
if not exist "node_modules\" (
    echo [INFO] First time setup: Installing dependencies...
    cmd /c npm install --omit=dev
    if %ERRORLEVEL% NEQ 0 (
        color 0c
        echo [ERROR] Failed to install npm dependencies.
        pause
        exit /b 1
    )
)

echo [OK] Starting Server on http://localhost:3000...
echo Keep this window OPEN while printing BarTender labels.
echo ========================================================
echo.
node server.js

if %ERRORLEVEL% NEQ 0 (
    color 0c
    echo.
    echo [ERROR] Backend server stopped unexpectedly.
    pause
)
